---
title: Vision
section: vision
created_at: 2024-03-20T00:00:00Z
updated_at: 2024-03-20T00:00:00Z
translation_key: vision-description
translated_from: de
translated_at: 2024-03-20T00:00:00Z
---

Merhaba.
